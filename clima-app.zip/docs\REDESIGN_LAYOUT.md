# Redesign estrutural do dashboard

O dashboard foi reorganizado em Grid para desktop: sidebar à esquerda, área central com previsão resumida, cartões complementares e gráficos, e painel de clima atual vertical à direita. O painel atual não é mais uma faixa horizontal da área central.

A previsão resumida mostra sete dias; a previsão completa mantém os quinze dias em `fullForecastGrid`. O histórico continua em uma seção própria. Em telas menores, o Grid se transforma em fluxo vertical e a navegação usa o comportamento compacto já definido pelos breakpoints.

O painel atual usa a camada `.weather-animation` como ilustração meteorológica principal. O emoji permanece apenas como fallback semântico, mas é ocultado visualmente no painel grande. As camadas têm `pointer-events: none`, não bloqueiam interação e respeitam `prefers-reduced-motion`.
